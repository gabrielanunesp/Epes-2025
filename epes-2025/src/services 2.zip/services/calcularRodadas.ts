export interface ResultadoRodada {
  ea: number;
  demanda: number;
  receita: number;
  custo: number;
  lucro: number;
  reinvestimento: number;
  caixaFinal: number;
  cvu: number;
  backlog: boolean;
  satisfacao: number;
  evento?: string;
  share?: number;           // % para UI (compatível)
  shareFraction?: number;   // 0..1
}

// ===== NOVO: tipos para cálculo coletivo =====
export interface EquipeInput {
  id: string;                 // identificador do time
  preco: number;
  qualidade: number;          // 0..100
  marketingBonus: number;     // ex.: 0..100 (seu padrão)
  equipeBonus: number;        // 0..100
  beneficioBonus: number;     // 0|10|15|20 – cupom/brinde/frete
  capacidade: number;         // limite de vendas
  publicoAlvo: string;        // "Jovens (15–24 anos)", etc.
  caixaAcumulado: number;     // saldo anterior (para somar 80%)
}

export interface ParametrosGlobais {
  refPrice: number;           // P*
  marketSize: number;         // tamanho total do mercado
  beta: number;               // temperatura do softmax
  shareCap?: number;          // teto de share por time (opcional)
  fixedTeamCost: number;      // custo fixo por rodada
  ea50: number;               // ponto médio da sigmoide (se usado)
  eaK: number;                // inclinação da sigmoide (se usado)
  reinvestRate: number;       // 0.20
}

export interface ResultadoColetivoPorTime extends ResultadoRodada {
  teamId: string;
  unitCost: number;
}

export interface ResultadoColetivo {
  resultados: ResultadoColetivoPorTime[]; // um por equipe
  ranking: { teamId: string; lucro: number }[]; // ordenado desc
  somaSales: number;
  somaShares: number; // ~1
}

// ================= Helpers =================
const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));

export function calcularCVU(qualidade: number, eficiencia: number): number {
  const base = 20;
  const alpha = 0.2;
  const beta = 0.1;
  const cvu = base + alpha * qualidade - beta * eficiencia;
  return Math.max(0, parseFloat(cvu.toFixed(2)));
}

const priceScore = (p: number, refPrice: number) => {
  const denom = 0.5 * refPrice || 1;
  return clamp(1 - (p - refPrice) / denom, 0, 1);
};

const marketingScoreFromBonus = (bonusPct: number, boost: number) => {
  const spend = Math.max(0, bonusPct) * 1000; // compatível com seu custo
  const raw = Math.log(1 + spend) / 10;       // retorno decrescente
  return clamp((1 + boost) * raw, 0, 1);
};

const softmax = (arr: number[], beta: number) => {
  const scaled = arr.map((x) => x * beta);
  const m = Math.max(...scaled);
  const exps = scaled.map((x) => Math.exp(x - m));
  const sum = exps.reduce((a, b) => a + b, 0) || 1;
  return exps.map((e) => e / sum);
};

const capShares = (shares: number[], cap?: number) => {
  if (cap == null) return shares;
  const capped = shares.map((x) => Math.min(x, cap));
  const sum = capped.reduce((a, b) => a + b, 0) || 1;
  return capped.map((x) => x / sum);
};

// ===== Mapas (mantidos do seu código) =====
const qualidadeMultiplicador: Record<string, number> = {
  "Jovens (15–24 anos)": 0.8,
  "Adultos (25–40 anos)": 1.0,
  "Sêniores (40+)": 1.2,
  "Classe A/B": 1.25,
  "Classe C/D": 0.8,
};

const marketingMultiplicador: Record<string, number> = {
  "Jovens (15–24 anos)": 1.3,
  "Adultos (25–40 anos)": 1.0,
  "Sêniores (40+)": 1.2,
  "Classe A/B": 1.1,
  "Classe C/D": 1.15,
};

const equipeMultiplicador: Record<string, number> = {
  "Jovens (15–24 anos)": 0.9,
  "Adultos (25–40 anos)": 1.0,
  "Sêniores (40+)": 1.3,
  "Classe A/B": 1.1,
  "Classe C/D": 0.9,
};

const elasticidadePreco: Record<string, number> = {
  "Jovens (15–24 anos)": 1.2,
  "Adultos (25–40 anos)": 1.0,
  "Sêniores (40+)": 0.8,
  "Classe A/B": 0.9,
  "Classe C/D": 1.5,
};

const beneficioBonusExtra: Record<string, number> = {
  "Cupom|Classe C/D": 5,
  "Brinde|Jovens (15–24 anos)": 5,
  "Frete grátis|Adultos (25–40 anos)": 5,
  "Frete grátis|Sêniores (40+)": 5,
};

// ========== CÁLCULO COLETIVO ==========
export function calcularRodadaColetiva(
  equipes: EquipeInput[],
  params: Partial<ParametrosGlobais> = {}
): ResultadoColetivo {
  const {
    refPrice = 100,
    marketSize = 3000,
    beta = 1.1,
    shareCap,
    fixedTeamCost = 5000,
    ea50 = 100,
    eaK = 30,
    reinvestRate = 0.2,
  } = params;

  if (!equipes || equipes.length === 0) {
    return { resultados: [], ranking: [], somaSales: 0, somaShares: 0 };
  }

  // 1) EA por equipe (linear, com públicos)
  const eas = equipes.map((t) => {
    const publico = (t.publicoAlvo || "").trim();
    const pScore = priceScore(t.preco > 0 ? t.preco : refPrice, refPrice);
    const mScore = marketingScoreFromBonus(
      t.marketingBonus ?? 0,
      (marketingMultiplicador[publico] ?? 1) - 1
    );

    const beneficioTipo =
      t.beneficioBonus === 10 ? "Cupom" :
      t.beneficioBonus === 15 ? "Brinde" :
      t.beneficioBonus === 20 ? "Frete grátis" : "Nenhum";
    const bonusExtra = beneficioBonusExtra[`${beneficioTipo}|${publico}`] ?? 0;
    const beneficio = (t.beneficioBonus ?? 0) + bonusExtra;

    const eaLinear =
      100 * pScore +
      (t.qualidade ?? 0) * (qualidadeMultiplicador[publico] ?? 1) +
      100 * mScore +
      (t.equipeBonus ?? 0) * (equipeMultiplicador[publico] ?? 1) +
      beneficio;

    // opcional: apertar/afrouxar com sigmoide ao redor de ea50
    const prop = 1 / (1 + Math.exp(-(eaLinear - ea50) / eaK));
    return { eaLinear, prop };
  });

  // 2) Softmax em cima do EA (usamos eaLinear para competição)
  let shares = softmax(eas.map((e) => e.eaLinear), beta);
  shares = capShares(shares, shareCap);
  const somaShares = shares.reduce((a, b) => a + b, 0);

  // 3) Demanda bruta com elasticidade e preço
  const demandRaw = equipes.map((t, i) => {
    const publico = (t.publicoAlvo || "").trim();
    const eps = elasticidadePreco[publico] ?? 1.0;
    const price = t.preco > 0 ? t.preco : refPrice;
    const priceFactor = Math.pow(refPrice / price, eps);
    return marketSize * shares[i] * priceFactor;
  });

  // 4) Vendas (capacidade)
  const sales = equipes.map((t, i) => Math.min(demandRaw[i], Math.max(0, t.capacidade || 0)));
  const somaSales = sales.reduce((a, b) => a + b, 0);

  // 5) Custos e resultados
  const resultados: ResultadoColetivoPorTime[] = equipes.map((t, i) => {
    const publico = (t.publicoAlvo || "").trim();
    const eficiencia = Math.min(100, 50 + (t.equipeBonus ?? 0)); // proxy simples
    const unit = calcularCVU(t.qualidade ?? 0, eficiencia);

    const receita = sales[i] * (t.preco > 0 ? t.preco : refPrice);
    const custoVariavel = sales[i] * unit;
    const custoMarketing = (t.marketingBonus ?? 0) * 1000;
    const custoEquipe = (t.equipeBonus ?? 0) * 1000;
    const beneficioTipo =
      t.beneficioBonus === 10 ? "Cupom" :
      t.beneficioBonus === 15 ? "Brinde" :
      t.beneficioBonus === 20 ? "Frete grátis" : "Nenhum";
    const bonusExtra = beneficioBonusExtra[`${beneficioTipo}|${publico}`] ?? 0;
    const custoBeneficio = ( (t.beneficioBonus ?? 0) + bonusExtra ) * 1000;

    const custoTotal = custoVariavel + custoMarketing + custoEquipe + custoBeneficio + fixedTeamCost;
    const lucro = receita - custoTotal;

    const reinvest = lucro > 0 ? lucro * reinvestRate : 0;
    const cashToFinal = lucro > 0 ? lucro * (1 - reinvestRate) : 0;

    const eaLinear = eas[i].eaLinear;
    const shareFraction = demandRaw[i] / marketSize; // para UI

    const resultado: ResultadoColetivoPorTime = {
      teamId: t.id,
      ea: parseFloat(eaLinear.toFixed(2)),
      demanda: Math.round(demandRaw[i]),
      receita: parseFloat(receita.toFixed(2)),
      custo: parseFloat(custoTotal.toFixed(2)),
      lucro: parseFloat(lucro.toFixed(2)),
      reinvestimento: parseFloat(reinvest.toFixed(2)),
      caixaFinal: parseFloat((t.caixaAcumulado + Math.max(0, cashToFinal)).toFixed(2)),
      cvu: parseFloat(unit.toFixed(2)),
      backlog: demandRaw[i] > sales[i],
      satisfacao: Math.min(100, eaLinear / 2),
      evento: demandRaw[i] > sales[i] ? "PENALIDADE_NEXT" : undefined,
      share: parseFloat((clamp(shareFraction, 0, 1) * 100).toFixed(2)),
      shareFraction: clamp(shareFraction, 0, 1),
      unitCost: parseFloat(unit.toFixed(2)),
    };

    return resultado;
  });

  // 6) Ranking por lucro
  const ranking = resultados
    .map((r) => ({ teamId: (r as any).teamId as string, lucro: r.lucro }))
    .sort((a, b) => b.lucro - a.lucro);

  return { resultados, ranking, somaSales, somaShares };
}

// ====== PREVIEW para uma equipe (ainda coletivo) ======
export function calcularRodadaPreview(
  todasEquipes: EquipeInput[],
  timeId: string,
  params?: Partial<ParametrosGlobais>
): ResultadoColetivoPorTime | null {
  const full = calcularRodadaColetiva(todasEquipes, params);
  return full.resultados.find((r) => (r as any).teamId === timeId) || null;
}

// ====== DEPRECATED: cálculo individual (proíbo uso na produção) ======
export function calcularRodada(_: any): ResultadoRodada {
  throw new Error(
    "[calcularRodada] Removido o cálculo individual. Use calcularRodadaColetiva(equipes, params) ou calcularRodadaPreview(todasEquipes, timeId, params)."
  );
}
